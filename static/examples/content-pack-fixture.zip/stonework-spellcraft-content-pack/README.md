# Integration fixture

Deliberately incomplete: three names and one story/appearance per supported ancestry, a handful of shared traits. Only wolfkin, demon and golem have generation ingredients. Other arrays are empty and explicitly reported. No generated record is an established event. Full content production and mechanical mapping of the remaining pools remain future integration work.
