# Codex implementation handoff — pack 11

Implement reviewable support for `ss-household-scenes-and-ambient-life` against the actual repository, not an assumed engine. Read README, manifest, shared contract, original handoff, and the supplied baseline snapshot before changing code.

1. Inspect the existing importer, content models, state transitions, save versions, and tests. The source handoff says only character foundations currently import; verify the repository rather than declaring expansion support.
2. Validate this pack and its declared dependencies using the integration kit. Add strict typed parsing for each record type, rejecting extra fields, unresolved IDs, unsupported schema versions, and invalid ancestry combinations. Keep candidate data separate from instantiated save facts.
3. Make narrative records available only through appropriate continuity and disclosure filters. Keep private-template data server-side and out of ordinary prompts, client bundles, search, and logs.
4. Treat mechanics-proposal records as review data, never executable content. Resolve nulls explicitly, review balance against the snapshot, and implement only selected allowlisted effects. Do not auto-enable all proposals or create an arbitrary effect interpreter.
5. Preserve one assignment per actor, explicit human Advance, personal/shared wallets, independent ownership, prepared-versus-known distinctions, resident agency, and existing accepted identities. Eris and Selene remain external players.
6. Add migrations and integration tests for duplicate requests, stale tabs, cancel/refund at each stage, save/reload, departure, permissions, and unsupported controls. Written scenarios in pack 16 are not passing tests.
7. Report changed files, enabled versus still-proposed capabilities, tests actually run, and unresolved design decisions. Do not silently rewrite these content IDs or old saves.

Target content counts are in manifest.json. The mechanics file may contain more or fewer records than content because some entries share a lifecycle proposal and some are narrative-only. Do not grant inventory, money, knowledge, or relationships merely by importing this pack.
