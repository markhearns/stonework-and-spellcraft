# Household scenes, fanservice and ambient life

Pack `ss-household-scenes-and-ambient-life` · version 0.1.0 · schema 1 · **draft-for-implementation**.

## Scope

160 complete content candidates and 0 separate provisional mechanics proposals. No runtime importer, executable rule, game image, accepted character, or completed play event is created by this pack.

| File | Delivered records |
|---|---:|
| `scene-template.json` | 80 |
| `ambient-line.json` | 80 |
| `proposed-mechanics.json` | 0 |

## Reading order

Read this README, the shared contract and numbered handoff in the integration kit, then the manifest, vocabulary, content files, proposed mechanics, and validation report. Use `CODEX-HANDOFF.md` as the implementation task. Proposals remain disabled until reviewed and mapped to typed runtime code.

## Dependencies actually delivered

- `stonework-spellcraft-character-foundations` 1.0.0

Expansion dependencies are separately delivered sibling ZIPs, not embedded copies. The unchanged character foundations ZIP and prototype snapshot are in the integration kit. Do not replace dependency IDs with names or generate competing identities. Install dependencies before enabling references; missing dependencies must block activation rather than silently drop fields.

## Distinct concepts

- Eighty three-choice scenes with eighty separate short ambient lines.
- Twenty ordinary, twenty playful, twenty-five flirtatious, and fifteen romantic scenes preserve specific voices, practical humour, and confident non-explicit sensuality.
- Five direct continuations cite the unchanged foundational interaction seeds; the remaining scenes broaden their branching treatment rather than add a competing seed pool.

## Intentionally excluded

- Automatic wardrobe changes, involuntary exposure, compulsory touch, romantic meters, and attention decay.

## Implementation still required

- Scene-instance branch selection, continuity-aware candidate filtering, non-expiring invitations, and repeat avoidance.
- Separate conversational intent from actual physical participation, ownership changes, and work actions.

Unknown prices, quantities, durations, and capacities are explicit nulls where the source supplies no defensible baseline. Null never means free or infinite; block the relevant state-changing operation until resolved. An empty reference/input list means no qualifying supplied reference/input is claimed. It does not authorize invented resources or bypass prerequisites.

Narrative arrays are candidates, not executable commands. All discovery, scene, relationship, and chapter resolutions require actual selected play. Appearance text never equips garments. Reading never grants personal mastery. Work advances only on explicit human Advance; optional conversation and decoration do not consume work.

## Validation and limitations

Exact shortfalls: none. Structural checks and reference resolution are automated by the separately supplied validation utility. Reports enumerate the checks actually executed. Runtime QA scenarios are specifications only: no game build, UI, save migration, or economic simulation has been tested here. Semantic review is model-authored, not human approval or external originality clearance.

Selectable labels express intent. Even a positive response in the kiss or hand-holding scene is not a performed physical action; the actual interaction must retain a separate current mutual choice. Reusable decline wording is intentional.

The controlling shared contract, this pack's original numbered handoff, and the read-only prototype snapshot are also included locally in `reference/`. The integration kit adds the unchanged foundations dependency and reusable validator.
