# Tutorial copy, explanations and integration scenarios

Pack `ss-tutorials-explanations-and-qa` · version 0.1.0 · schema 1 · **draft-for-implementation**.

## Scope

144 complete content candidates and 0 separate provisional mechanics proposals. No runtime importer, executable rule, game image, accepted character, or completed play event is created by this pack.

| File | Delivered records |
|---|---:|
| `help-card.json` | 32 |
| `feedback-copy.json` | 48 |
| `acceptance-scenario.json` | 64 |
| `proposed-mechanics.json` | 0 |

## Reading order

Read this README, the shared contract and numbered handoff in the integration kit, then the manifest, vocabulary, content files, proposed mechanics, and validation report. Use `CODEX-HANDOFF.md` as the implementation task. Proposals remain disabled until reviewed and mapped to typed runtime code.

## Dependencies actually delivered

No expansion or foundations dependency; the supplied prototype snapshot remains the read-only baseline.

Expansion dependencies are separately delivered sibling ZIPs, not embedded copies. The unchanged character foundations ZIP and prototype snapshot are in the integration kit. Do not replace dependency IDs with names or generate competing identities. Install dependencies before enabling references; missing dependencies must block activation rather than silently drop fields.

## Distinct concepts

- Thirty-two plain-language help cards distinguish current supplied rules from future proposals.
- Forty-eight context-gated feedback messages cover ownership, missing knowledge, stale state, wardrobe, capacity, agency, and recovery.
- Sixty-four concrete acceptance scenarios specify positive paths and failures across runtime state, persistence, content imports, and private disclosure.

## Intentionally excluded

- Runnable game scripts, invented runtime test results, fabricated UI controls, and unsupported rules disguised as current help.

## Implementation still required

- Map each feedback message to a real authoritative state check, with accessible controls and an ordinary text alternative.
- Implement and execute the acceptance scenarios in the actual project, then report real results separately from content validation.

Unknown prices, quantities, durations, and capacities are explicit nulls where the source supplies no defensible baseline. Null never means free or infinite; block the relevant state-changing operation until resolved. An empty reference/input list means no qualifying supplied reference/input is claimed. It does not authorize invented resources or bypass prerequisites.

Narrative arrays are candidates, not executable commands. All discovery, scene, relationship, and chapter resolutions require actual selected play. Appearance text never equips garments. Reading never grants personal mastery. Work advances only on explicit human Advance; optional conversation and decoration do not consume work.

## Validation and limitations

Exact shortfalls: none. Structural checks and reference resolution are automated by the separately supplied validation utility. Reports enumerate the checks actually executed. Runtime QA scenarios are specifications only: no game build, UI, save migration, or economic simulation has been tested here. Semantic review is model-authored, not human approval or external originality clearance.

The current-rule help cards reflect the supplied read-only prototype snapshot or explicit shared contract, not independent verification of a live repository. General contract cards have empty relatedBaselineIds because the snapshot supplies no rule ID for those boundaries.
The 64 acceptance scenarios are written test designs only. Structural validation of their schemas and references does not execute their attempted actions or prove their expected outcomes.

The controlling shared contract, this pack's original numbered handoff, and the read-only prototype snapshot are also included locally in `reference/`. The integration kit adds the unchanged foundations dependency and reusable validator.
