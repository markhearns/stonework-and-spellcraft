# Materials and component properties

Pack `ss-materials-and-properties` · version 0.1.0 · schema 1 · **draft-for-implementation**.

## Scope

72 complete content candidates and 13 separate provisional mechanics proposals. No runtime importer, executable rule, game image, accepted character, or completed play event is created by this pack.

| File | Delivered records |
|---|---:|
| `material.json` | 60 |
| `property-concept.json` | 12 |
| `proposed-mechanics.json` | 13 |

## Reading order

Read this README, the shared contract and numbered handoff in the integration kit, then the manifest, vocabulary, content files, proposed mechanics, and validation report. Use `CODEX-HANDOFF.md` as the implementation task. Proposals remain disabled until reviewed and mapped to typed runtime code.

## Dependencies actually delivered

No expansion or foundations dependency; the supplied prototype snapshot remains the read-only baseline.

Expansion dependencies are separately delivered sibling ZIPs, not embedded copies. The unchanged character foundations ZIP and prototype snapshot are in the integration kit. Do not replace dependency IDs with names or generate competing identities. Install dependencies before enabling references; missing dependencies must block activation rather than silently drop fields.

## Distinct concepts

- Property-based alternatives span mineral, plant, textile, ceramic, glass, ink, and made substrates.
- Each material supplies a practical role, a concrete substitute, and a material-specific limit.
- Rare samples deepen observation; ordinary comfort never depends on obtaining them.

## Intentionally excluded

- Body-part ingredients, sentient raw materials, scarcity gates for basic comfort, and universal substitution tags.

## Implementation still required

- Add a reviewed material/property eligibility registry without changing existing four property meanings.
- Implement acquisition and testing separately; import must not create inventory.

Unknown prices, quantities, durations, and capacities are explicit nulls where the source supplies no defensible baseline. Null never means free or infinite; block the relevant state-changing operation until resolved. An empty reference/input list means no qualifying supplied reference/input is claimed. It does not authorize invented resources or bypass prerequisites.

Narrative arrays are candidates, not executable commands. All discovery, scene, relationship, and chapter resolutions require actual selected play. Appearance text never equips garments. Reading never grants personal mastery. Work advances only on explicit human Advance; optional conversation and decoration do not consume work.

## Validation and limitations

Exact shortfalls: none. Structural checks and reference resolution are automated by the separately supplied validation utility. Reports enumerate the checks actually executed. Runtime QA scenarios are specifications only: no game build, UI, save migration, or economic simulation has been tested here. Semantic review is model-authored, not human approval or external originality clearance.

An eight-record material pilot and its vocabulary were written before completing the material file. Qualification tags are candidate metadata; acceptance tests must be reviewed, and none alter current recipe substitution automatically. Resonant vibration is explicitly unrelated to the game's sensual Resonance.

The controlling shared contract, this pack's original numbered handoff, and the read-only prototype snapshot are also included locally in `reference/`. The integration kit adds the unchanged foundations dependency and reusable validator.
