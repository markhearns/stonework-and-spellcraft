# Personal arcs and descriptive relationships

Pack `ss-personal-arcs-and-relationships` · version 0.1.0 · schema 1 · **draft-for-implementation**.

## Scope

78 complete content candidates and 0 separate provisional mechanics proposals. No runtime importer, executable rule, game image, accepted character, or completed play event is created by this pack.

| File | Delivered records |
|---|---:|
| `personal-arc.json` | 42 |
| `relationship-development.json` | 36 |
| `proposed-mechanics.json` | 0 |

## Reading order

Read this README, the shared contract and numbered handoff in the integration kit, then the manifest, vocabulary, content files, proposed mechanics, and validation report. Use `CODEX-HANDOFF.md` as the implementation task. Proposals remain disabled until reviewed and mapped to typed runtime code.

## Dependencies actually delivered

- `stonework-spellcraft-character-foundations` 1.0.0

Expansion dependencies are separately delivered sibling ZIPs, not embedded copies. The unchanged character foundations ZIP and prototype snapshot are in the integration kit. Do not replace dependency IDs with names or generate competing identities. Install dependencies before enabling references; missing dependencies must block activation rather than silently drop fields.

## Distinct concepts

- Forty-two three-chapter follow-through arcs reference the unchanged first two seeds of every ancestry.
- Twelve friendships, ten collaborations, eight reciprocal romances, and six friendly disagreements.
- Golem development begins with actual post-awakening choice; spirit introductions do not invent death or ancient history.

## Intentionally excluded

- New character pools, ancestry-prescribed personalities, automatic romance, and reward-based intimacy.

## Implementation still required

- Instance chapter state only from accepted events; preserve unresolved alternatives and private disclosures.
- Keep source-story adoption, actual chapter participation, optional invitations, and accepted identity changes distinct.

Unknown prices, quantities, durations, and capacities are explicit nulls where the source supplies no defensible baseline. Null never means free or infinite; block the relevant state-changing operation until resolved. An empty reference/input list means no qualifying supplied reference/input is claimed. It does not authorize invented resources or bypass prerequisites.

Narrative arrays are candidates, not executable commands. All discovery, scene, relationship, and chapter resolutions require actual selected play. Appearance text never equips garments. Reading never grants personal mastery. Work advances only on explicit human Advance; optional conversation and decoration do not consume work.

## Validation and limitations

Exact shortfalls: none. Structural checks and reference resolution are automated by the separately supplied validation utility. Reports enumerate the checks actually executed. Runtime QA scenarios are specifications only: no game build, UI, save migration, or economic simulation has been tested here. Semantic review is model-authored, not human approval or external originality clearance.



The controlling shared contract, this pack's original numbered handoff, and the read-only prototype snapshot are also included locally in `reference/`. The integration kit adds the unchanged foundations dependency and reusable validator.
