# Household artifacts and crafting recipes

Pack `ss-artifacts-and-recipes` · version 0.1.0 · schema 1 · **draft-for-implementation**.

## Scope

80 complete content candidates and 40 separate provisional mechanics proposals. No runtime importer, executable rule, game image, accepted character, or completed play event is created by this pack.

| File | Delivered records |
|---|---:|
| `artifact-concept.json` | 40 |
| `recipe-concept.json` | 40 |
| `proposed-mechanics.json` | 40 |

## Reading order

Read this README, the shared contract and numbered handoff in the integration kit, then the manifest, vocabulary, content files, proposed mechanics, and validation report. Use `CODEX-HANDOFF.md` as the implementation task. Proposals remain disabled until reviewed and mapped to typed runtime code.

## Dependencies actually delivered

- `ss-materials-and-properties` 0.1.0

Expansion dependencies are separately delivered sibling ZIPs, not embedded copies. The unchanged character foundations ZIP and prototype snapshot are in the integration kit. Do not replace dependency IDs with names or generate competing identities. Install dependencies before enabling references; missing dependencies must block activation rather than silently drop fields.

## Distinct concepts

- Separate reading, washroom, kitchen, textile, correspondence, storage, laboratory, garden, and shared-space uses.
- Each recipe names a concrete assembly step and the actual material candidates it relies on.
- Fabrication creates an inactive owned item; only a later explicit installation enables a bounded use.

## Intentionally excluded

- Copies of the eleven baseline artifacts, unattended production, invisible extra workers, and magical consent effects.

## Implementation still required

- A reviewed new-artifact recipe registry and owner-preserving craft/install state machine.
- Typed manual-use affordances with explicit local scope and non-stacking limits.

Unknown prices, quantities, durations, and capacities are explicit nulls where the source supplies no defensible baseline. Null never means free or infinite; block the relevant state-changing operation until resolved. An empty reference/input list means no qualifying supplied reference/input is claimed. It does not authorize invented resources or bypass prerequisites.

Narrative arrays are candidates, not executable commands. All discovery, scene, relationship, and chapter resolutions require actual selected play. Appearance text never equips garments. Reading never grants personal mastery. Work advances only on explicit human Advance; optional conversation and decoration do not consume work.

## Validation and limitations

Exact shortfalls: none. Structural checks and reference resolution are automated by the separately supplied validation utility. Reports enumerate the checks actually executed. Runtime QA scenarios are specifications only: no game build, UI, save migration, or economic simulation has been tested here. Semantic review is model-authored, not human approval or external originality clearance.

Forty new artifact concepts pair one-to-one with forty recipes. None redefines the eleven baseline artifact IDs. All prototypes remain optional conveniences rather than prerequisites for privacy, basic warmth, meals, or care. The doorway draft comb explicitly requires a new air-flow adaptation; the existing water-guidance name does not make that effect executable.

The controlling shared contract, this pack's original numbered handoff, and the read-only prototype snapshot are also included locally in `reference/`. The integration kit adds the unchanged foundations dependency and reusable validator.
