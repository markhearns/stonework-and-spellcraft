# Correspondence, commissions, gifts and keepsakes

Pack `ss-letters-commissions-and-gifts` · version 0.1.0 · schema 1 · **draft-for-implementation**.

## Scope

100 complete content candidates and 1 separate provisional mechanics proposals. No runtime importer, executable rule, game image, accepted character, or completed play event is created by this pack.

| File | Delivered records |
|---|---:|
| `letter-template.json` | 40 |
| `commission-concept.json` | 24 |
| `gift-or-keepsake.json` | 36 |
| `proposed-mechanics.json` | 1 |

## Reading order

Read this README, the shared contract and numbered handoff in the integration kit, then the manifest, vocabulary, content files, proposed mechanics, and validation report. Use `CODEX-HANDOFF.md` as the implementation task. Proposals remain disabled until reviewed and mapped to typed runtime code.

## Dependencies actually delivered

- `ss-artifacts-and-recipes` 0.1.0

Expansion dependencies are separately delivered sibling ZIPs, not embedded copies. The unchanged character foundations ZIP and prototype snapshot are in the integration kit. Do not replace dependency IDs with names or generate competing identities. Install dependencies before enabling references; missing dependencies must block activation rather than silently drop fields.

## Distinct concepts

- Forty original letters with actual-result gates, reply directions, and private disclosure limits.
- Fifteen baseline-grounded commissions and nine explicitly unavailable-until-implemented artifact trials.
- Thirty-six physically distinct gifts and keepsakes with real ownership, display, and departure boundaries.

## Intentionally excluded

- Deadlines, flattering-letter rewards, duplicate production payouts, affection purchases, and automatic inventory.

## Implementation still required

- Draft versus sent correspondence, accepted offer terms, authoritative inventory transfers, and funded settlement receipts.
- Verify baseline luminous-copy shared income is accounted for once and not paid again as a narrative commission reward.

Unknown prices, quantities, durations, and capacities are explicit nulls where the source supplies no defensible baseline. Null never means free or infinite; block the relevant state-changing operation until resolved. An empty reference/input list means no qualifying supplied reference/input is claimed. It does not authorize invented resources or bypass prerequisites.

Narrative arrays are candidates, not executable commands. All discovery, scene, relationship, and chapter resolutions require actual selected play. Appearance text never equips garments. Reading never grants personal mastery. Work advances only on explicit human Advance; optional conversation and decoration do not consume work.

## Validation and limitations

Exact shortfalls: none. Structural checks and reference resolution are automated by the separately supplied validation utility. Reports enumerate the checks actually executed. Runtime QA scenarios are specifications only: no game build, UI, save migration, or economic simulation has been tested here. Semantic review is model-authored, not human approval or external originality clearance.

The nine trial commissions have empty supportedWorkReferences intentionally: their real artifact and recipe dependencies are delivered, but those work rules are not current executable baseline work. Common references identify the exact proposed dependencies without mislabelling them as supported.

The controlling shared contract, this pack's original numbered handoff, and the read-only prototype snapshot are also included locally in `reference/`. The integration kit adds the unchanged foundations dependency and reusable validator.
