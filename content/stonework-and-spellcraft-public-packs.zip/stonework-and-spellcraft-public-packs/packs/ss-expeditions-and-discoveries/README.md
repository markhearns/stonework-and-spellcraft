# Expedition sites, leads and reusable discoveries

Pack `ss-expeditions-and-discoveries` · version 0.1.0 · schema 1 · **draft-for-implementation**.

## Scope

126 complete content candidates and 0 separate provisional mechanics proposals. No runtime importer, executable rule, game image, accepted character, or completed play event is created by this pack.

| File | Delivered records |
|---|---:|
| `site-template.json` | 18 |
| `lead-template.json` | 54 |
| `discovery-template.json` | 54 |
| `proposed-mechanics.json` | 0 |

## Reading order

Read this README, the shared contract and numbered handoff in the integration kit, then the manifest, vocabulary, content files, proposed mechanics, and validation report. Use `CODEX-HANDOFF.md` as the implementation task. Proposals remain disabled until reviewed and mapped to typed runtime code.

## Dependencies actually delivered

- `ss-materials-and-properties` 0.1.0

Expansion dependencies are separately delivered sibling ZIPs, not embedded copies. The unchanged character foundations ZIP and prototype snapshot are in the integration kit. Do not replace dependency IDs with names or generate competing identities. Install dependencies before enabling references; missing dependencies must block activation rather than silently drop fields.

## Distinct concepts

- Ruins, workshops, groves, waterworks, observatories, archives, markets, and quiet settlements each have distinct questions.
- Every lead offers a non-risky or narrower alternative and a comfortable retreat.
- Observation, interpretation, return, archive deposit, and personal learning remain separate.

## Intentionally excluded

- Unknown loot auto-ownership, automatic destination revelation, repeated reward farming, and home devastation while travelling.

## Implementation still required

- Gate each lead and discovery by actual revealed state, route permissions, and explicit player choices.
- Implement any travel costs, accepted rewards, and one-time receipts separately from these narrative templates.

Unknown prices, quantities, durations, and capacities are explicit nulls where the source supplies no defensible baseline. Null never means free or infinite; block the relevant state-changing operation until resolved. An empty reference/input list means no qualifying supplied reference/input is claimed. It does not authorize invented resources or bypass prerequisites.

Narrative arrays are candidates, not executable commands. All discovery, scene, relationship, and chapter resolutions require actual selected play. Appearance text never equips garments. Reading never grants personal mastery. Work advances only on explicit human Advance; optional conversation and decoration do not consume work.

## Validation and limitations

Exact shortfalls: none. Structural checks and reference resolution are automated by the separately supplied validation utility. Reports enumerate the checks actually executed. Runtime QA scenarios are specifications only: no game build, UI, save migration, or economic simulation has been tested here. Semantic review is model-authored, not human approval or external originality clearance.

Eighteen sites each have exactly three separately gated leads and one discovery per lead. Material and principle references are conceptual comparison targets, never loot or knowledge rewards. No travel durations, fixed payouts, inventory quantities, combats, or new campaign geography are asserted as implemented rules; proposed reward mapping belongs to future expedition code.

The controlling shared contract, this pack's original numbered handoff, and the read-only prototype snapshot are also included locally in `reference/`. The integration kit adds the unchanged foundations dependency and reusable validator.
