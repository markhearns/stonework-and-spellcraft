# Equipment and evolving signature items

Pack `ss-equipment-and-signature-items` · version 0.1.0 · schema 1 · **draft-for-implementation**.

## Scope

96 complete content candidates and 45 separate provisional mechanics proposals. No runtime importer, executable rule, game image, accepted character, or completed play event is created by this pack.

| File | Delivered records |
|---|---:|
| `equipment-concept.json` | 48 |
| `inscription-concept.json` | 48 |
| `proposed-mechanics.json` | 45 |

## Reading order

Read this README, the shared contract and numbered handoff in the integration kit, then the manifest, vocabulary, content files, proposed mechanics, and validation report. Use `CODEX-HANDOFF.md` as the implementation task. Proposals remain disabled until reviewed and mapped to typed runtime code.

## Dependencies actually delivered

- `ss-materials-and-properties` 0.1.0

Expansion dependencies are separately delivered sibling ZIPs, not embedded copies. The unchanged character foundations ZIP and prototype snapshot are in the integration kit. Do not replace dependency IDs with names or generate competing identities. Install dependencies before enabling references; missing dependencies must block activation rather than silently drop fields.

## Distinct concepts

- Sixteen recognizable signature foci emphasize repeated use and replaceable parts rather than loot tiers.
- Sixteen tools, eight field kits, and eight accessories have distinct practical roles without free bonuses.
- Inscription scope is local and visible; private information and consent are never magically inferred.

## Intentionally excluded

- Wardrobe-only garments, automatic equipping, +1/+2 item ladders, and extra hidden focus slots.

## Implementation still required

- Implement host compatibility and personal ownership separately from appearance selection.
- Preserve the four baseline inscriptions exactly; review the other 44 as new rules.

Unknown prices, quantities, durations, and capacities are explicit nulls where the source supplies no defensible baseline. Null never means free or infinite; block the relevant state-changing operation until resolved. An empty reference/input list means no qualifying supplied reference/input is claimed. It does not authorize invented resources or bypass prerequisites.

Narrative arrays are candidates, not executable commands. All discovery, scene, relationship, and chapter resolutions require actual selected play. Appearance text never equips garments. Reading never grants personal mastery. Work advances only on explicit human Advance; optional conversation and decoration do not consume work.

## Validation and limitations

Exact shortfalls: none. Structural checks and reference resolution are automated by the separately supplied validation utility. Reports enumerate the checks actually executed. Runtime QA scenarios are specifications only: no game build, UI, save migration, or economic simulation has been tested here. Semantic review is model-authored, not human approval or external originality clearance.

Four entries accurately describe the existing focus inscriptions and point to their baseline IDs with mechanicsProposalId null. The remaining 44 inscriptions are new proposals. Mundane tools, field kits, and accessories carry no default numerical bonus. Hosts without a supported preparation workflow must remain descriptive until an explicit adapter is approved.

The controlling shared contract, this pack's original numbered handoff, and the read-only prototype snapshot are also included locally in `reference/`. The integration kit adds the unchanged foundations dependency and reusable validator.
