# Art briefs and visual continuity

Pack `ss-art-and-visual-production` · version 0.1.0 · schema 1 · **draft-for-implementation**.

## Scope

93 complete content candidates and 0 separate provisional mechanics proposals. No runtime importer, executable rule, game image, accepted character, or completed play event is created by this pack.

| File | Delivered records |
|---|---:|
| `room-art-brief.json` | 24 |
| `object-art-brief.json` | 48 |
| `wardrobe-art-brief.json` | 21 |
| `proposed-mechanics.json` | 0 |

## Reading order

Read this README, the shared contract and numbered handoff in the integration kit, then the manifest, vocabulary, content files, proposed mechanics, and validation report. Use `CODEX-HANDOFF.md` as the implementation task. Proposals remain disabled until reviewed and mapped to typed runtime code.

## Dependencies actually delivered

- `ss-equipment-and-signature-items` 0.1.0
- `ss-rooms-furnishings-and-synergies` 0.1.0
- `stonework-spellcraft-character-foundations` 1.0.0

Expansion dependencies are separately delivered sibling ZIPs, not embedded copies. The unchanged character foundations ZIP and prototype snapshot are in the integration kit. Do not replace dependency IDs with names or generate competing identities. Install dependencies before enabling references; missing dependencies must block activation rather than silently drop fields.

## Distinct concepts

- Twenty-four briefs point to the actual delivered room purposes; forty-eight point to the actual delivered equipment concepts.
- Twenty-one adult wardrobe studies reference real foundation garments with slot-compatible combinations.
- Shared eye-level room framing and phase-lighting guidance preserve visual continuity without inventing world state.

## Intentionally excluded

- Rendered-image claims, missing-reference identity edits, ancestry uniforms, unapproved anatomy, and baked-in gameplay effects.

## Implementation still required

- Approved reference-image input, selected concept state, anatomy and garment-fit review, and a separate image production workflow.
- Keep generated assets from mutating equipment, room, resident, or disclosure state; overlays remain an optional UI layer.

Unknown prices, quantities, durations, and capacities are explicit nulls where the source supplies no defensible baseline. Null never means free or infinite; block the relevant state-changing operation until resolved. An empty reference/input list means no qualifying supplied reference/input is claimed. It does not authorize invented resources or bypass prerequisites.

Narrative arrays are candidates, not executable commands. All discovery, scene, relationship, and chapter resolutions require actual selected play. Appearance text never equips garments. Reading never grants personal mastery. Work advances only on explicit human Advance; optional conversation and decoration do not consume work.

## Validation and limitations

Exact shortfalls: none. Structural checks and reference resolution are automated by the separately supplied validation utility. Reports enumerate the checks actually executed. Runtime QA scenarios are specifications only: no game build, UI, save migration, or economic simulation has been tested here. Semantic review is model-authored, not human approval or external originality clearance.



The controlling shared contract, this pack's original numbered handoff, and the read-only prototype snapshot are also included locally in `reference/`. The integration kit adds the unchanged foundations dependency and reusable validator.
