# Neighbouring communities, services and recurring contacts

Pack `ss-communities-services-and-visitors` · version 0.1.0 · schema 1 · **draft-for-implementation**.

## Scope

64 complete content candidates and 1 separate provisional mechanics proposals. No runtime importer, executable rule, game image, accepted character, or completed play event is created by this pack.

| File | Delivered records |
|---|---:|
| `community-template.json` | 8 |
| `contact-role.json` | 32 |
| `service-concept.json` | 24 |
| `proposed-mechanics.json` | 1 |

## Reading order

Read this README, the shared contract and numbered handoff in the integration kit, then the manifest, vocabulary, content files, proposed mechanics, and validation report. Use `CODEX-HANDOFF.md` as the implementation task. Proposals remain disabled until reviewed and mapped to typed runtime code.

## Dependencies actually delivered

No expansion or foundations dependency; the supplied prototype snapshot remains the read-only baseline.

Expansion dependencies are separately delivered sibling ZIPs, not embedded copies. The unchanged character foundations ZIP and prototype snapshot are in the integration kit. Do not replace dependency IDs with names or generate competing identities. Install dependencies before enabling references; missing dependencies must block activation rather than silently drop fields.

## Distinct concepts

- Eight communities with their own craft concerns and projects; four independent contact roles and three distinct services each.
- Physical fit trials, provenance-aware exchanges, controlled repairs, and optional lessons complement rather than replace discovery.

## Intentionally excluded

- Fixed recruit identities, absolute regional canon, automatic markets, and paid knowledge grants.

## Implementation still required

- Persist instantiated communities and contacts separately from candidate templates.
- Service-specific adapters, explicit offers, wallet authority, stock reservations, and idempotent settlement.

Unknown prices, quantities, durations, and capacities are explicit nulls where the source supplies no defensible baseline. Null never means free or infinite; block the relevant state-changing operation until resolved. An empty reference/input list means no qualifying supplied reference/input is claimed. It does not authorize invented resources or bypass prerequisites.

Narrative arrays are candidates, not executable commands. All discovery, scene, relationship, and chapter resolutions require actual selected play. Appearance text never equips garments. Reading never grants personal mastery. Work advances only on explicit human Advance; optional conversation and decoration do not consume work.

## Validation and limitations

Exact shortfalls: none. Structural checks and reference resolution are automated by the separately supplied validation utility. Reports enumerate the checks actually executed. Runtime QA scenarios are specifications only: no game build, UI, save migration, or economic simulation has been tested here. Semantic review is model-authored, not human approval or external originality clearance.



The controlling shared contract, this pack's original numbered handoff, and the read-only prototype snapshot are also included locally in `reference/`. The integration kit adds the unchanged foundations dependency and reusable validator.
