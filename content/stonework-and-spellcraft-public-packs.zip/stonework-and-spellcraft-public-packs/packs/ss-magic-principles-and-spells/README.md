# Magic principles and bounded spell constructions

Pack `ss-magic-principles-and-spells` · version 0.1.0 · schema 1 · **draft-for-implementation**.

## Scope

126 complete content candidates and 69 separate provisional mechanics proposals. No runtime importer, executable rule, game image, accepted character, or completed play event is created by this pack.

| File | Delivered records |
|---|---:|
| `principle-concept.json` | 24 |
| `spell-construction.json` | 72 |
| `spell-explanation.json` | 30 |
| `proposed-mechanics.json` | 69 |

## Reading order

Read this README, the shared contract and numbered handoff in the integration kit, then the manifest, vocabulary, content files, proposed mechanics, and validation report. Use `CODEX-HANDOFF.md` as the implementation task. Proposals remain disabled until reviewed and mapped to typed runtime code.

## Dependencies actually delivered

- `ss-materials-and-properties` 0.1.0

Expansion dependencies are separately delivered sibling ZIPs, not embedded copies. The unchanged character foundations ZIP and prototype snapshot are in the integration kit. Do not replace dependency IDs with names or generate competing identities. Install dependencies before enabling references; missing dependencies must block activation rather than silently drop fields.

## Distinct concepts

- Twenty-four clearly bounded grammar extensions, each with falsifiable observation questions and a concrete small trial.
- Separate current-form explanations, partial fits, new rules, and prohibited requests.
- No inference from archive availability to personal mastery, preparation, or executable effects.

## Intentionally excluded

- Mind control, universal reality editing, resurrection farming, disposable summoned people, and automatic mana taxes.

## Implementation still required

- A principle registry distinct from personal knowledge and preparation records.
- Explicit form-level adapters; sharing a principle never enables an arbitrary requested effect.

Unknown prices, quantities, durations, and capacities are explicit nulls where the source supplies no defensible baseline. Null never means free or infinite; block the relevant state-changing operation until resolved. An empty reference/input list means no qualifying supplied reference/input is claimed. It does not authorize invented resources or bypass prerequisites.

Narrative arrays are candidates, not executable commands. All discovery, scene, relationship, and chapter resolutions require actual selected play. Appearance text never equips garments. Reading never grants personal mastery. Work advances only on explicit human Advance; optional conversation and decoration do not consume work.

## Validation and limitations

Exact shortfalls: none. Structural checks and reference resolution are automated by the separately supplied validation utility. Reports enumerate the checks actually executed. Runtime QA scenarios are specifications only: no game build, UI, save migration, or economic simulation has been tested here. Semantic review is model-authored, not human approval or external originality clearance.

The 72 constructions comprise 24 ordinary concepts using only existing principles (including four exact baseline references), 36 ordinary explorations of delivered new principles, and 12 exceptional concepts. Only the four baseline references claim executable support. All new ordinary forms propose one assigned phase and reusable components rather than a mana tax. Exceptional null costs and durations deliberately prevent activation until reviewed.

The controlling shared contract, this pack's original numbered handoff, and the read-only prototype snapshot are also included locally in `reference/`. The integration kit adds the unchanged foundations dependency and reusable validator.
