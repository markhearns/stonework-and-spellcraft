# Background capability mappings, training and earned perks

Pack `ss-backgrounds-training-and-perks` · version 0.1.0 · schema 1 · **draft-for-implementation**.

## Scope

102 complete content candidates and 48 separate provisional mechanics proposals. No runtime importer, executable rule, game image, accepted character, or completed play event is created by this pack.

| File | Delivered records |
|---|---:|
| `background-mapping.json` | 30 |
| `starting-package-concept.json` | 12 |
| `perk-concept.json` | 36 |
| `training-opportunity.json` | 24 |
| `proposed-mechanics.json` | 48 |

## Reading order

Read this README, the shared contract and numbered handoff in the integration kit, then the manifest, vocabulary, content files, proposed mechanics, and validation report. Use `CODEX-HANDOFF.md` as the implementation task. Proposals remain disabled until reviewed and mapped to typed runtime code.

## Dependencies actually delivered

- `ss-artifacts-and-recipes` 0.1.0
- `ss-equipment-and-signature-items` 0.1.0
- `stonework-spellcraft-character-foundations` 1.0.0

Expansion dependencies are separately delivered sibling ZIPs, not embedded copies. The unchanged character foundations ZIP and prototype snapshot are in the integration kit. Do not replace dependency IDs with names or generate competing identities. Install dependencies before enabling references; missing dependencies must block activation rather than silently drop fields.

## Distinct concepts

- Thirty exact source-occupation mappings, including one explicit no-fit result.
- Twelve small starters, thirty-six narrow earned investments, and twenty-four concrete teaching exercises.
- Reversible fitting, measured comparisons, uncertainty retention, and source-linked planning offer different technical uses rather than blanket expertise.

## Intentionally excluded

- Automatic vocation grants, inherited golem skills, romance-based knowledge transfer, new identity pools, and hidden aptitude or consent meters.
- Free respec refunds, stacked room/perk productivity loops, and perks that gate basic accessibility, provenance, safe withdrawal, or ordinary conversation.

## Implementation still required

- Strict mapping and proposal loaders that preserve original occupation records and accepted character state.
- Typed new-character admission, real earned progression and preparation checks, separately costed technical jobs, and idempotent acquisition receipts.
- Regression tests for prospective golem history, rank-zero starters, no extra focus slots, shared support caps, voluntary teaching, cancellation, and save/reload.

Unknown prices, quantities, durations, and capacities are explicit nulls where the source supplies no defensible baseline. Null never means free or infinite; block the relevant state-changing operation until resolved. An empty reference/input list means no qualifying supplied reference/input is claimed. It does not authorize invented resources or bypass prerequisites.

Narrative arrays are candidates, not executable commands. All discovery, scene, relationship, and chapter resolutions require actual selected play. Appearance text never equips garments. Reading never grants personal mastery. Work advances only on explicit human Advance; optional conversation and decoration do not consume work.

## Validation and limitations

Exact shortfalls: none. Structural checks and reference resolution are automated by the separately supplied validation utility. Reports enumerate the checks actually executed. Runtime QA scenarios are specifications only: no game build, UI, save migration, or economic simulation has been tested here. Semantic review is model-authored, not human approval or external originality clearance.

All thirty originally unmapped occupation IDs are covered exactly once; the original foundation files remain unchanged. A null suggestedStartingPackageId is a deliberate no-fit decision, not missing content.
All thirty-six ancestryBasis values are null: these investments are not biological or ancestry-derived perks. Golem vocations remain prospective; no package creates pre-awakening knowledge or a childhood.
The twenty-four training opportunities are narrative offers with no mechanicsProposalId because they grant no result. Any chosen work or advancement must use an actual supported learning rule or the separately reviewed perk investment.
One limited principle and one basic practice are candidates per starter, with zero ranks, no earned advancement, and one focus slot. The independently chosen uninscribed tool is a real delivered equipment definition, not an automatically owned item.

The controlling shared contract, this pack's original numbered handoff, and the read-only prototype snapshot are also included locally in `reference/`. The integration kit adds the unchanged foundations dependency and reusable validator.
