# Room purposes, furnishings and understandable synergies

Pack `ss-rooms-furnishings-and-synergies` · version 0.1.0 · schema 1 · **draft-for-implementation**.

## Scope

120 complete content candidates and 60 separate provisional mechanics proposals. No runtime importer, executable rule, game image, accepted character, or completed play event is created by this pack.

| File | Delivered records |
|---|---:|
| `room-purpose.json` | 24 |
| `furnishing-concept.json` | 72 |
| `adjacency-synergy.json` | 24 |
| `proposed-mechanics.json` | 60 |

## Reading order

Read this README, the shared contract and numbered handoff in the integration kit, then the manifest, vocabulary, content files, proposed mechanics, and validation report. Use `CODEX-HANDOFF.md` as the implementation task. Proposals remain disabled until reviewed and mapped to typed runtime code.

## Dependencies actually delivered

- `ss-materials-and-properties` 0.1.0

Expansion dependencies are separately delivered sibling ZIPs, not embedded copies. The unchanged character foundations ZIP and prototype snapshot are in the integration kit. Do not replace dependency IDs with names or generate competing identities. Install dependencies before enabling references; missing dependencies must block activation rather than silently drop fields.

## Distinct concepts

- Natural eye-level room briefs and optional artwork overlays.
- Functional fittings state practical scope; decorative choices cannot acquire bonuses.
- Visible optional adjacency support never penalizes a small household or duplicates baseline crafting support.

## Intentionally excluded

- Wall-building, forced furniture placement puzzles, additional resident places from chairs, and prison treatment of underground rooms.

## Implementation still required

- Separate decorative appearance from functional fitting work and actual capacity allocation.
- Review the twelve capped contribution proposals against actual progress arithmetic and existing bonuses.

Unknown prices, quantities, durations, and capacities are explicit nulls where the source supplies no defensible baseline. Null never means free or infinite; block the relevant state-changing operation until resolved. An empty reference/input list means no qualifying supplied reference/input is claimed. It does not authorize invented resources or bypass prerequisites.

Narrative arrays are candidates, not executable commands. All discovery, scene, relationship, and chapter resolutions require actual selected play. Appearance text never equips garments. Reading never grants personal mastery. Work advances only on explicit human Advance; optional conversation and decoration do not consume work.

## Validation and limitations

Exact shortfalls: none. Structural checks and reference resolution are automated by the separately supplied validation utility. Reports enumerate the checks actually executed. Runtime QA scenarios are specifications only: no game build, UI, save migration, or economic simulation has been tested here. Semantic review is model-authored, not human approval or external originality clearance.

There are 24 room purposes, one purely decorative choice plus two functional fittings per room (24 decorative/48 functional), and 24 synergies. Twelve synergies propose a capped eligible work contribution; twelve are purely descriptive layout conveniences. Ordinary below-ground living is never confinement. Care places remain distinct from the 25-resident main estate and optional annex capacities.

The controlling shared contract, this pack's original numbered handoff, and the read-only prototype snapshot are also included locally in `reference/`. The integration kit adds the unchanged foundations dependency and reusable validator.
